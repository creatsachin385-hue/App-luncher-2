# Preserve ActivityOptions hidden method call for Freeform Window launch on One UI Core
-keepclassmembers class android.app.ActivityOptions {
    public void setLaunchWindowingMode(int);
}
