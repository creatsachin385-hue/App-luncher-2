package com.example.applauncher.ui

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.example.applauncher.R
import com.example.applauncher.service.EdgeOverlayService
import com.example.applauncher.util.PrefsManager

/**
 * Permission Onboarding, Samsung One UI "Deep Sleeping Apps" Exemption Guide,
 * Low Power Mode Toggle, and Reachability Ergonomics Configurator.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefsManager: PrefsManager
    private lateinit var tvOverlayStatus: TextView
    private lateinit var tvBatteryStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefsManager = PrefsManager(this)

        tvOverlayStatus = findViewById(R.id.tv_overlay_status)
        tvBatteryStatus = findViewById(R.id.tv_battery_status)

        val btnGrantOverlay = findViewById<Button>(R.id.btn_grant_overlay)
        val btnDisableBatteryOpt = findViewById<Button>(R.id.btn_disable_battery_opt)
        val btnSamsungDeviceCare = findViewById<Button>(R.id.btn_samsung_device_care)
        val btnStartService = findViewById<Button>(R.id.btn_start_service)
        val btnStopService = findViewById<Button>(R.id.btn_stop_service)

        val switchLowPower = findViewById<SwitchCompat>(R.id.switch_low_power)
        val rbLeftEdge = findViewById<RadioButton>(R.id.rb_left_edge)
        val rbRightEdge = findViewById<RadioButton>(R.id.rb_right_edge)
        val seekHandleHeight = findViewById<SeekBar>(R.id.seek_handle_height)
        val tvHandleHeightVal = findViewById<TextView>(R.id.tv_handle_height_value)

        // 1. Overlay Permission Onboarding
        btnGrantOverlay.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        // 2. Standard Android Doze / Battery Optimization Exemption
        btnDisableBatteryOpt.setOnClickListener {
            requestIgnoreBatteryOptimizations()
        }

        // 3. Direct Deep-Link into Samsung One UI Core "Device Care -> Battery"
        btnSamsungDeviceCare.setOnClickListener {
            openSamsungDeviceCareBattery()
        }

        // 4. Start / Stop Overlay Service Controls
        btnStartService.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this,
                    "Please grant 'Appear on top' Overlay Permission first.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            val serviceIntent = Intent(this, EdgeOverlayService::class.java)
            ContextCompat.startForegroundService(this, serviceIntent)
            Toast.makeText(this, "Edge Sidebar Active!", Toast.LENGTH_SHORT).show()
        }

        btnStopService.setOnClickListener {
            val stopIntent = Intent(this, EdgeOverlayService::class.java).apply {
                action = EdgeOverlayService.ACTION_STOP_SERVICE
            }
            startService(stopIntent)
            Toast.makeText(this, "Edge Sidebar Stopped", Toast.LENGTH_SHORT).show()
        }

        // 5. Low Power Mode (< 40 MB RAM, 0ms animations, 36dp icons, 1.5MB cache)
        switchLowPower.isChecked = prefsManager.isLowPowerMode
        switchLowPower.setOnCheckedChangeListener { _, isChecked ->
            prefsManager.isLowPowerMode = isChecked
        }

        // 6. Reachability Mode (Edge Side & Handle Height for One-Handed Tablet Grip)
        if (prefsManager.isLeftEdge) rbLeftEdge.isChecked = true else rbRightEdge.isChecked = true
        rbLeftEdge.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) prefsManager.isLeftEdge = true
        }
        rbRightEdge.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) prefsManager.isLeftEdge = false
        }

        val currentHeightDp = prefsManager.handleHeightDp
        seekHandleHeight.max = 180 // 80dp .. 260dp
        seekHandleHeight.progress = (currentHeightDp - 80).coerceIn(0, 180)
        tvHandleHeightVal.text = "${currentHeightDp} dp"

        seekHandleHeight.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val dp = progress + 80
                tvHandleHeightVal.text = "$dp dp"
                if (fromUser) {
                    prefsManager.handleHeightDp = dp
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionBadges()
        // Auto-start overlay if permission is already granted
        if (Settings.canDrawOverlays(this)) {
            ContextCompat.startForegroundService(
                this,
                Intent(this, EdgeOverlayService::class.java)
            )
        }
    }

    private fun refreshPermissionBadges() {
        val overlayGranted = Settings.canDrawOverlays(this)
        tvOverlayStatus.text = if (overlayGranted) {
            "Overlay Permission (Appear on top): GRANTED"
        } else {
            "Overlay Permission (Appear on top): REQUIRED"
        }
        tvOverlayStatus.setTextColor(if (overlayGranted) 0xFF4CAF50.toInt() else 0xFFFF9800.toInt())

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val ignoringBatteryOpt = pm.isIgnoringBatteryOptimizations(packageName)
        tvBatteryStatus.text = if (ignoringBatteryOpt) {
            "One UI Battery Status: Unrestricted (Exempt from Deep Sleep)"
        } else {
            "One UI Battery Status: Optimized (Tap below to prevent Deep Sleep killing)"
        }
        tvBatteryStatus.setTextColor(
            if (ignoringBatteryOpt) 0xFF4CAF50.toInt() else 0xFFFF9800.toInt()
        )
    }

    @SuppressLint("BatteryLife")
    private fun requestIgnoreBatteryOptimizations() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    /**
     * Launches Samsung One UI Core's Device Care Battery Settings directly on Galaxy Tab A7 Lite,
     * falling back to App Details if the OEM activity is renamed.
     */
    private fun openSamsungDeviceCareBattery() {
        val samsungComponents = listOf(
            ComponentName(
                "com.samsung.android.lool",
                "com.samsung.android.sm.battery.ui.BatteryActivity"
            ),
            ComponentName(
                "com.samsung.android.sm_cn",
                "com.samsung.android.sm.ui.battery.BatteryActivity"
            )
        )
        for (component in samsungComponents) {
            try {
                val intent = Intent().apply {
                    this.component = component
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
                Toast.makeText(
                    this,
                    "Add App Launcher to 'Never auto sleeping apps'",
                    Toast.LENGTH_LONG
                ).show()
                return
            } catch (_: Exception) {
                // Try next fallback
            }
        }
        // Fallback: open App Info where user can tap "Battery -> Unrestricted"
        val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(appDetails)
        Toast.makeText(
            this,
            "Tap 'Battery' -> Select 'Unrestricted'",
            Toast.LENGTH_LONG
        ).show()
    }
}
