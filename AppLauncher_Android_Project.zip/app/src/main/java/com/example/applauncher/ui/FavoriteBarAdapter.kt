package com.example.applauncher.ui

import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.applauncher.R
import com.example.applauncher.data.AppRepository
import com.example.applauncher.model.AppInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class FavoriteBarAdapter(
    private val lifecycleScope: CoroutineScope,
    private val repository: AppRepository,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppAction: (AppInfo, AppGridAdapter.ContextAction) -> Unit
) : ListAdapter<AppInfo, FavoriteBarAdapter.FavViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite_app, parent, false)
        return FavViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class FavViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.iv_fav_icon)
        private var iconJob: Job? = null

        fun bind(app: AppInfo) {
            itemView.contentDescription = app.label
            iconJob?.cancel()

            val cached = repository.getCachedIcon(app.uniqueKey)
            if (cached != null) {
                ivIcon.setImageBitmap(cached)
            } else {
                ivIcon.setImageDrawable(null)
                iconJob = lifecycleScope.launch {
                    val bmp = repository.loadIconAsync(app)
                    if (bmp != null) ivIcon.setImageBitmap(bmp)
                }
            }

            itemView.setOnClickListener { onAppClick(app) }
            itemView.setOnLongClickListener { view ->
                val popup = PopupMenu(view.context, view)
                popup.menu.apply {
                    add(Menu.NONE, 1, 1, "Open Normal")
                    add(Menu.NONE, 2, 2, "Open in Split Screen")
                    add(Menu.NONE, 3, 3, "Open in Freeform / Pop-up Window")
                    add(Menu.NONE, 4, 4, "Unpin from Favorites")
                }
                popup.setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        1 -> onAppAction(app, AppGridAdapter.ContextAction.OPEN_NORMAL)
                        2 -> onAppAction(app, AppGridAdapter.ContextAction.OPEN_SPLIT_SCREEN)
                        3 -> onAppAction(app, AppGridAdapter.ContextAction.OPEN_FREEFORM_POPUP)
                        4 -> onAppAction(app, AppGridAdapter.ContextAction.TOGGLE_PIN)
                    }
                    true
                }
                popup.show()
                true
            }
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<AppInfo>() {
        override fun areItemsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean =
            oldItem.uniqueKey == newItem.uniqueKey

        override fun areContentsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean =
            oldItem == newItem
    }
}
