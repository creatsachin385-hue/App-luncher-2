package com.example.applauncher.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View

/**
 * Custom lightweight A-Z vertical index scroller.
 * Allocates zero objects inside onDraw() to keep frame render times < 1ms on PowerVR GE8320.
 */
class AlphabetFastScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val sections = arrayOf(
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
        "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "#"
    )

    private var activeIndex = -1
    var onSectionSelected: ((String) -> Unit)? = null

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFB0B8C8.toInt()
        textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP,
            10f,
            resources.displayMetrics
        )
    }

    private val activeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF4FC3F7.toInt()
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP,
            12f,
            resources.displayMetrics
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val count = sections.size
        val availHeight = height - paddingTop - paddingBottom
        if (availHeight <= 0) return

        val itemHeight = availHeight.toFloat() / count
        val centerX = width / 2f

        for (i in 0 until count) {
            val paint = if (i == activeIndex) activeTextPaint else textPaint
            val baselineY = paddingTop + itemHeight * i + (itemHeight / 2f) -
                    ((paint.descent() + paint.ascent()) / 2f)
            canvas.drawText(sections[i], centerX, baselineY, paint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val availHeight = (height - paddingTop - paddingBottom).coerceAtLeast(1)
                val relativeY = (event.y - paddingTop).coerceIn(0f, availHeight.toFloat())
                val index = ((relativeY / availHeight) * sections.size).toInt()
                    .coerceIn(0, sections.lastIndex)

                if (index != activeIndex) {
                    activeIndex = index
                    onSectionSelected?.invoke(sections[index])
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeIndex = -1
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
