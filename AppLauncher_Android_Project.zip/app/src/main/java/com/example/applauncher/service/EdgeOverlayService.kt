package com.example.applauncher.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.applauncher.R
import com.example.applauncher.data.AppRepository
import com.example.applauncher.data.PackageEventReceiver
import com.example.applauncher.model.AppInfo
import com.example.applauncher.ui.AlphabetFastScrollView
import com.example.applauncher.ui.AppGridAdapter
import com.example.applauncher.ui.FavoriteBarAdapter
import com.example.applauncher.ui.MainActivity
import com.example.applauncher.util.PrefsManager
import com.example.applauncher.util.T9Matcher
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Ultra-low overhead ForegroundService managing:
 * 1. Floating Edge Handle (TYPE_APPLICATION_OVERLAY) with vertical drag & inward swipe detection.
 * 2. 3-second Idle Timer that shrinks and fades the handle to 20% opacity (80% translucent).
 * 3. Zero-polling Immersive Mode Auto-Hide (hides handle in fullscreen games & video players).
 * 4. Smooth hardware-layer drawer slide with Dual-View UI (Favorites, Instant T9 Search, A-Z Grid).
 * 5. Zero WakeLocks: Completely dormant when drawer is closed.
 */
class EdgeOverlayService : LifecycleService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var windowManager: WindowManager
    private lateinit var prefsManager: PrefsManager
    private lateinit var repository: AppRepository
    private lateinit var packageReceiver: PackageEventReceiver

    private var handleRootView: View? = null
    private var handlePillView: View? = null
    private lateinit var handleParams: WindowManager.LayoutParams

    private var drawerRootView: FrameLayout? = null
    private var drawerPanelView: View? = null
    private lateinit var drawerParams: WindowManager.LayoutParams

    private var gridAdapter: AppGridAdapter? = null
    private var favoriteAdapter: FavoriteBarAdapter? = null
    private var searchInput: EditText? = null
    private var emptyPinnedText: TextView? = null

    private var isDrawerOpen = false
    private var isImmersiveFullscreen = false
    private var currentSearchQuery = ""

    private val mainHandler = Handler(Looper.getMainLooper())
    private val idleRunnable = Runnable { enterIdleHandleState() }

    /**
     * Screen-off receiver trims icon cache immediately when tablet display sleeps.
     */
    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                closeDrawer(immediate = true)
                repository.trimMemory(aggressive = false)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefsManager = PrefsManager(applicationContext)
        repository = AppRepository(applicationContext, prefsManager)

        startForeground(NOTIFICATION_ID, buildMinimalNotification())

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        prefsManager.registerListener(this)
        packageReceiver = PackageEventReceiver { repository.reloadAppsAsync() }
        packageReceiver.register(this)
        registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))

        createEdgeHandleOverlay()
        createDrawerOverlay()
        observeRepository()
        repository.reloadAppsAsync()
        scheduleIdleFade()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    // =========================================================================
    // 1. Floating Edge Handle Setup, Drag Physics & Idle State
    // =========================================================================

    @SuppressLint("ClickableViewAccessibility")
    private fun createEdgeHandleOverlay() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.view_edge_handle, null)
        val pill = view.findViewById<View>(R.id.handle_pill)

        val handleWidthPx = dpToPx(24)
        val handleHeightPx = dpToPx(prefsManager.handleHeightDp)

        handleParams = WindowManager.LayoutParams(
            handleWidthPx,
            handleHeightPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or if (prefsManager.isLeftEdge) Gravity.START else Gravity.END
            x = 0
            y = clampHandleY(prefsManager.handleYOffsetPx, handleHeightPx)
        }

        // Zero-polling Immersive Fullscreen Detector (Auto-hides handle in games/video players)
        ViewCompat.setOnApplyWindowInsetsListener(view) { _, insets ->
            val barsVisible = insets.isVisible(WindowInsetsCompat.Type.statusBars()) ||
                    insets.isVisible(WindowInsetsCompat.Type.navigationBars())
            val nowImmersive = !barsVisible
            if (nowImmersive != isImmersiveFullscreen) {
                isImmersiveFullscreen = nowImmersive
                updateHandleVisibility()
            }
            insets
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var initialWindowY = 0
        var isVerticalDragging = false
        var swipeTriggered = false

        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    wakeHandleFromIdle()
                    downRawX = event.rawX
                    downRawY = event.rawY
                    initialWindowY = handleParams.y
                    isVerticalDragging = false
                    swipeTriggered = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    val isLeft = prefsManager.isLeftEdge
                    val inwardSwipe = if (isLeft) dx > touchSlop * 1.5f else dx < -touchSlop * 1.5f

                    if (!isVerticalDragging && !swipeTriggered && inwardSwipe && abs(dx) > abs(dy)) {
                        swipeTriggered = true
                        openDrawer()
                    } else if (!swipeTriggered && abs(dy) > touchSlop) {
                        isVerticalDragging = true
                        handleParams.y = clampHandleY(
                            initialWindowY + dy.toInt(),
                            handleParams.height
                        )
                        safeUpdateViewLayout(view, handleParams)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isVerticalDragging) {
                        prefsManager.handleYOffsetPx = handleParams.y
                        scheduleIdleFade()
                    } else if (!swipeTriggered && event.actionMasked == MotionEvent.ACTION_UP) {
                        // Single tap opens the drawer
                        openDrawer()
                    } else {
                        scheduleIdleFade()
                    }
                    true
                }

                else -> false
            }
        }

        handleRootView = view
        handlePillView = pill
        windowManager.addView(view, handleParams)
    }

    private fun wakeHandleFromIdle() {
        mainHandler.removeCallbacks(idleRunnable)
        val pill = handlePillView ?: return
        pill.animate().cancel()
        pill.alpha = 0.90f
        pill.scaleX = 1.0f
    }

    /**
     * After 3 seconds of inactivity, shrinks the pill into a thin line and reduces alpha to 0.20f (80% translucent).
     */
    private fun scheduleIdleFade() {
        mainHandler.removeCallbacks(idleRunnable)
        mainHandler.postDelayed(idleRunnable, IDLE_TIMEOUT_MS)
    }

    private fun enterIdleHandleState() {
        val pill = handlePillView ?: return
        val pivotX = if (prefsManager.isLeftEdge) 0f else pill.width.toFloat()
        pill.pivotX = pivotX
        if (prefsManager.isLowPowerMode) {
            pill.alpha = 0.20f
            pill.scaleX = 0.45f
        } else {
            pill.animate()
                .alpha(0.20f)
                .scaleX(0.45f)
                .setDuration(220L)
                .start()
        }
    }

    private fun updateHandleVisibility() {
        val view = handleRootView ?: return
        view.visibility = if (isDrawerOpen || isImmersiveFullscreen) View.GONE else View.VISIBLE
    }

    // =========================================================================
    // 2. Sliding Sidebar Drawer Overlay (Favorites, T9 Search, A-Z Grid)
    // =========================================================================

    private fun createDrawerOverlay() {
        // Intercept Back key inside focusable overlay container to close drawer cleanly
        val container = object : FrameLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    closeDrawer(immediate = false)
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }

        // Tapping outside the drawer panel on the dim scrim closes the drawer
        container.setBackgroundColor(0x55000000)
        container.setOnClickListener { closeDrawer(immediate = false) }
        container.visibility = View.GONE

        inflateDrawerContentInto(container)

        drawerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Start NOT_FOCUSABLE while hidden; removed dynamically when opened
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        drawerRootView = container
        windowManager.addView(container, drawerParams)
    }

    private fun inflateDrawerContentInto(container: FrameLayout) {
        container.removeAllViews()
        val inflater = LayoutInflater.from(this)
        val panel = inflater.inflate(R.layout.view_sidebar_drawer, container, false)

        val panelLp = panel.layoutParams as FrameLayout.LayoutParams
        panelLp.gravity = if (prefsManager.isLeftEdge) Gravity.START else Gravity.END
        panel.layoutParams = panelLp
        // Consume clicks on panel so they don't bubble to the background scrim
        panel.setOnClickListener { }

        val rvFavorites = panel.findViewById<RecyclerView>(R.id.rv_favorites)
        val rvAllApps = panel.findViewById<RecyclerView>(R.id.rv_all_apps)
        val fastScroller = panel.findViewById<AlphabetFastScrollView>(R.id.alphabet_scroller)
        val etSearch = panel.findViewById<EditText>(R.id.et_search)
        val btnClearSearch = panel.findViewById<ImageButton>(R.id.btn_clear_search)
        val btnSettings = panel.findViewById<ImageButton>(R.id.btn_open_settings)
        emptyPinnedText = panel.findViewById(R.id.tv_empty_favorites)
        searchInput = etSearch

        // Setup Pinned / Favorites Horizontal Bar
        favoriteAdapter = FavoriteBarAdapter(
            lifecycleScope = lifecycleScope,
            repository = repository,
            onAppClick = { app ->
                closeDrawer(immediate = true)
                repository.launchApp(app, AppRepository.LaunchMode.NORMAL)
            },
            onAppAction = { app, action -> handleAppContextMenuAction(app, action) }
        )
        rvFavorites.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvFavorites.setHasFixedSize(true)
        rvFavorites.itemAnimator = null
        rvFavorites.adapter = favoriteAdapter

        // Setup Responsive Multi-Column Grid (3 cols in Portrait 800px, 4 cols in Landscape 1340px)
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val spanCount = if (isLandscape) 4 else 3
        val gridLayoutManager = GridLayoutManager(this, spanCount)

        gridAdapter = AppGridAdapter(
            lifecycleScope = lifecycleScope,
            repository = repository,
            onAppClick = { app ->
                closeDrawer(immediate = true)
                repository.launchApp(app, AppRepository.LaunchMode.NORMAL)
            },
            onAppAction = { app, action -> handleAppContextMenuAction(app, action) }
        )
        rvAllApps.layoutManager = gridLayoutManager
        rvAllApps.setHasFixedSize(true)
        rvAllApps.itemAnimator = null // Disable item animator to guarantee zero jank on Helio P22T
        rvAllApps.setItemViewCacheSize(18)
        rvAllApps.adapter = gridAdapter

        // Setup Instant T9 & Fuzzy Search Bar
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentSearchQuery = s?.toString() ?: ""
                btnClearSearch.visibility = if (currentSearchQuery.isEmpty()) View.GONE else View.VISIBLE
                applyFilterAndSubmit(repository.allApps.value)
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        btnClearSearch.setOnClickListener {
            etSearch.setText("")
        }

        btnSettings.setOnClickListener {
            closeDrawer(immediate = true)
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
        }

        // Setup A-Z Fast Scroller
        fastScroller.onSectionSelected = { letter ->
            val currentList = gridAdapter?.currentList ?: emptyList()
            val targetIndex = currentList.indexOfFirst { it.sectionLetter == letter }
            if (targetIndex != -1) {
                gridLayoutManager.scrollToPositionWithOffset(targetIndex, 0)
            }
        }

        container.addView(panel)
        drawerPanelView = panel

        // Re-bind current data
        applyFilterAndSubmit(repository.allApps.value)
        updateFavoritesList(repository.pinnedApps.value)
    }

    private fun handleAppContextMenuAction(app: AppInfo, action: AppGridAdapter.ContextAction) {
        when (action) {
            AppGridAdapter.ContextAction.OPEN_NORMAL -> {
                closeDrawer(immediate = true)
                repository.launchApp(app, AppRepository.LaunchMode.NORMAL)
            }
            AppGridAdapter.ContextAction.OPEN_SPLIT_SCREEN -> {
                closeDrawer(immediate = true)
                repository.launchApp(app, AppRepository.LaunchMode.SPLIT_SCREEN)
            }
            AppGridAdapter.ContextAction.OPEN_FREEFORM_POPUP -> {
                closeDrawer(immediate = true)
                repository.launchApp(app, AppRepository.LaunchMode.FREEFORM_POPUP)
            }
            AppGridAdapter.ContextAction.TOGGLE_PIN -> {
                prefsManager.togglePinApp(app.uniqueKey)
                repository.refreshPinnedState()
            }
            AppGridAdapter.ContextAction.APP_INFO -> {
                closeDrawer(immediate = true)
                repository.openAppDetails(app)
            }
        }
    }

    private fun observeRepository() {
        lifecycleScope.launch {
            repository.allApps.collectLatest { apps ->
                applyFilterAndSubmit(apps)
            }
        }
        lifecycleScope.launch {
            repository.pinnedApps.collectLatest { pinned ->
                updateFavoritesList(pinned)
            }
        }
    }

    private fun applyFilterAndSubmit(sourceApps: List<AppInfo>) {
        val query = currentSearchQuery
        val filtered = if (query.isBlank()) {
            sourceApps
        } else {
            sourceApps.filter { T9Matcher.matches(it, query) }
        }
        gridAdapter?.submitList(filtered)
    }

    private fun updateFavoritesList(pinned: List<AppInfo>) {
        favoriteAdapter?.submitList(pinned)
        emptyPinnedText?.visibility = if (pinned.isEmpty()) View.VISIBLE else View.GONE
    }

    // =========================================================================
    // 3. Hardware-Accelerated Expand & Collapse Mechanics
    // =========================================================================

    private fun openDrawer() {
        if (isDrawerOpen) return
        isDrawerOpen = true
        mainHandler.removeCallbacks(idleRunnable)
        updateHandleVisibility()

        val container = drawerRootView ?: return
        val panel = drawerPanelView ?: return

        // Make drawer focusable so search EditText can summon soft keyboard and Back key is caught
        drawerParams.flags = drawerParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        container.visibility = View.VISIBLE
        safeUpdateViewLayout(container, drawerParams)

        val panelLp = panel.layoutParams as FrameLayout.LayoutParams
        panelLp.gravity = if (prefsManager.isLeftEdge) Gravity.START else Gravity.END
        panel.layoutParams = panelLp

        if (prefsManager.isLowPowerMode) {
            panel.translationX = 0f
            container.alpha = 1f
        } else {
            val widthPx = dpToPx(if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) 420 else 320).toFloat()
            val startOffset = if (prefsManager.isLeftEdge) -widthPx else widthPx
            panel.translationX = startOffset
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)

            panel.animate()
                .translationX(0f)
                .setDuration(180L)
                .setInterpolator(DecelerateInterpolator())
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        // Immediately release hardware layer after animation to save GPU VRAM
                        panel.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                })
                .start()
        }
    }

    private fun closeDrawer(immediate: Boolean) {
        if (!isDrawerOpen) return
        isDrawerOpen = false

        val container = drawerRootView ?: return
        val panel = drawerPanelView ?: return

        // Hide soft keyboard if open
        searchInput?.let { input ->
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(input.windowToken, 0)
            if (input.text.isNotEmpty()) {
                input.setText("")
            }
        }

        // Restore FLAG_NOT_FOCUSABLE immediately so foreground app regains touch/key focus
        drawerParams.flags = drawerParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        safeUpdateViewLayout(container, drawerParams)

        val finishClose = {
            container.visibility = View.GONE
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            updateHandleVisibility()
            scheduleIdleFade()
            if (prefsManager.isLowPowerMode) {
                repository.trimMemory(aggressive = false)
            }
        }

        if (immediate || prefsManager.isLowPowerMode) {
            panel.animate().cancel()
            panel.translationX = 0f
            finishClose()
        } else {
            val targetOffset = if (prefsManager.isLeftEdge) -panel.width.toFloat() else panel.width.toFloat()
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            panel.animate()
                .translationX(targetOffset)
                .setDuration(150L)
                .setInterpolator(DecelerateInterpolator())
                .setListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        finishClose()
                    }
                })
                .start()
        }
    }

    // =========================================================================
    // 4. Configuration, SharedPreferences & Low-RAM Lifecycle Callbacks
    // =========================================================================

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Re-clamp handle Y coordinate for Portrait (800x1340) vs Landscape (1340x800)
        handleRootView?.let { view ->
            handleParams.y = clampHandleY(prefsManager.handleYOffsetPx, handleParams.height)
            safeUpdateViewLayout(view, handleParams)
        }
        // Rebuild drawer layout to switch cleanly between 3-col Portrait and 4-col Landscape
        drawerRootView?.let { container ->
            inflateDrawerContentInto(container)
        }
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        when (key) {
            PrefsManager.KEY_LEFT_EDGE,
            PrefsManager.KEY_HANDLE_HEIGHT_DP,
            PrefsManager.KEY_HANDLE_Y_PX -> {
                handleRootView?.let { view ->
                    handleParams.height = dpToPx(prefsManager.handleHeightDp)
                    handleParams.gravity = Gravity.TOP or if (prefsManager.isLeftEdge) Gravity.START else Gravity.END
                    handleParams.y = clampHandleY(prefsManager.handleYOffsetPx, handleParams.height)
                    safeUpdateViewLayout(view, handleParams)
                }
            }
            PrefsManager.KEY_LOW_POWER_MODE -> {
                repository.updatePowerMode(prefsManager.isLowPowerMode)
                gridAdapter?.notifyDataSetChanged()
                favoriteAdapter?.notifyDataSetChanged()
            }
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN
        ) {
            repository.trimMemory(
                aggressive = level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
            )
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        prefsManager.unregisterListener(this)
        packageReceiver.unregister(this)
        try {
            unregisterReceiver(screenOffReceiver)
        } catch (_: Exception) {}

        handleRootView?.let { safeRemoveView(it) }
        drawerRootView?.let { safeRemoveView(it) }
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        return super.onBind(intent)
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    private fun clampHandleY(desiredY: Int, handleHeight: Int): Int {
        val screenH = resources.displayMetrics.heightPixels
        val minTop = dpToPx(48)
        val maxBottom = (screenH - handleHeight - dpToPx(48)).coerceAtLeast(minTop)
        return desiredY.coerceIn(minTop, maxBottom)
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun safeUpdateViewLayout(view: View, params: WindowManager.LayoutParams) {
        try {
            if (view.isAttachedToWindow) {
                windowManager.updateViewLayout(view, params)
            }
        } catch (_: Exception) {}
    }

    private fun safeRemoveView(view: View) {
        try {
            windowManager.removeView(view)
        } catch (_: Exception) {}
    }

    private fun buildMinimalNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Edge Sidebar Service",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Keeps the Edge Sidebar handle ready with zero CPU wake-locks"
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }

        val openSettingsIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Edge sidebar active (Idle 0% CPU)")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setSilent(true)
            .setOngoing(true)
            .setContentIntent(openSettingsIntent)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "edge_overlay_channel"
        private const val IDLE_TIMEOUT_MS = 3_000L
        const val ACTION_STOP_SERVICE = "com.example.applauncher.STOP_SERVICE"
    }
}
