package com.example.applauncher.data

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.LruCache
import android.util.TypedValue
import android.widget.Toast
import com.example.applauncher.model.AppInfo
import com.example.applauncher.util.PrefsManager
import com.example.applauncher.util.T9Matcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.Collator
import java.util.Locale

/**
 * Singleton-style repository managing asynchronous PackageManager queries,
 * byte-bounded LRU icon caching (RGB_565 in Low Power Mode), and Samsung One UI Core
 * multi-window / split-screen / freeform pop-up intent launching.
 */
class AppRepository(
    private val context: Context,
    private val prefsManager: PrefsManager
) {
    private val packageManager: PackageManager = context.packageManager
    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val loadMutex = Mutex()

    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val allApps: StateFlow<List<AppInfo>> = _allApps.asStateFlow()

    private val _pinnedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val pinnedApps: StateFlow<List<AppInfo>> = _pinnedApps.asStateFlow()

    /**
     * Byte-bounded LruCache for rasterized app icons.
     * Standard Mode: 4,096 KB (4 MB)
     * Low Power Mode: 1,536 KB (1.5 MB)
     */
    private var iconCache: LruCache<String, Bitmap> = createIconCache(prefsManager.isLowPowerMode)

    private fun createIconCache(lowPower: Boolean): LruCache<String, Bitmap> {
        val maxKilobytes = if (lowPower) 1536 else 4096
        return object : LruCache<String, Bitmap>(maxKilobytes) {
            override fun sizeOf(key: String, value: Bitmap): Int {
                return (value.allocationByteCount / 1024).coerceAtLeast(1)
            }
        }
    }

    /**
     * Reconfigures cache ceiling and icon resolution when Low Power Mode is toggled.
     */
    fun updatePowerMode(lowPower: Boolean) {
        synchronized(this) {
            iconCache.evictAll()
            iconCache = createIconCache(lowPower)
        }
    }

    /**
     * Releases cached bitmaps for non-pinned apps when the sidebar closes or system requests memory trim.
     */
    fun trimMemory(aggressive: Boolean) {
        synchronized(this) {
            if (aggressive) {
                iconCache.evictAll()
            } else {
                val pinnedSet = prefsManager.getPinnedApps()
                val snapshot = iconCache.snapshot()
                for (key in snapshot.keys) {
                    if (!pinnedSet.contains(key)) {
                        iconCache.remove(key)
                    }
                }
            }
        }
    }

    /**
     * Queries all user-launchable activities asynchronously on Dispatchers.IO.
     */
    fun reloadAppsAsync() {
        repoScope.launch {
            loadMutex.withLock {
                val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }

                val resolveInfos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    packageManager.queryIntentActivities(
                        mainIntent,
                        PackageManager.ResolveInfoFlags.of(0L)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.queryIntentActivities(mainIntent, 0)
                }

                val pinnedKeys = prefsManager.getPinnedApps()
                val collator = Collator.getInstance(Locale.getDefault()).apply {
                    strength = Collator.PRIMARY
                }

                val ownPackage = context.packageName
                val loaded = ArrayList<AppInfo>(resolveInfos.size)

                for (info in resolveInfos) {
                    val activityInfo = info.activityInfo ?: continue
                    val pkgName = activityInfo.packageName
                    if (pkgName == ownPackage) continue

                    val rawLabel = info.loadLabel(packageManager)?.toString()?.trim()
                        ?.ifEmpty { pkgName } ?: pkgName
                    val uniqueKey = "$pkgName/${activityInfo.name}"
                    val firstChar = rawLabel.firstOrNull()?.uppercaseChar() ?: '#'
                    val section = if (firstChar in 'A'..'Z') firstChar.toString() else "#"

                    loaded.add(
                        AppInfo(
                            label = rawLabel,
                            labelLower = rawLabel.lowercase(Locale.getDefault()),
                            packageName = pkgName,
                            activityName = activityInfo.name,
                            t9Signature = T9Matcher.buildT9Signature(rawLabel),
                            sectionLetter = section,
                            isPinned = pinnedKeys.contains(uniqueKey)
                        )
                    )
                }

                loaded.sortWith { a, b -> collator.compare(a.label, b.label) }

                _allApps.value = loaded
                _pinnedApps.value = loaded.filter { it.isPinned }
            }
        }
    }

    /**
     * Refreshes pinned flags in-memory without re-querying PackageManager.
     */
    fun refreshPinnedState() {
        val pinnedKeys = prefsManager.getPinnedApps()
        val updated = _allApps.value.map { app ->
            val pinned = pinnedKeys.contains(app.uniqueKey)
            if (app.isPinned == pinned) app else app.copy(isPinned = pinned)
        }
        _allApps.value = updated
        _pinnedApps.value = updated.filter { it.isPinned }
    }

    /**
     * Returns cached Bitmap immediately if available, or null.
     */
    fun getCachedIcon(uniqueKey: String): Bitmap? {
        synchronized(this) {
            return iconCache.get(uniqueKey)
        }
    }

    /**
     * Decodes and downscales application icon on Dispatchers.IO.
     * In Low Power Mode: Rasterizes to 36dp using RGB_565 (2 bytes/pixel) when opaque, saving 50%+ RAM.
     * In Standard Mode: Rasterizes to 48dp using ARGB_8888.
     */
    suspend fun loadIconAsync(app: AppInfo): Bitmap? = withContext(Dispatchers.IO) {
        synchronized(this@AppRepository) {
            iconCache.get(app.uniqueKey)?.let { return@withContext it }
        }

        return@withContext try {
            val drawable = packageManager.getActivityIcon(app.componentName)
            val lowPower = prefsManager.isLowPowerMode
            val targetDp = if (lowPower) 36f else 48f
            val targetPx = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                targetDp,
                context.resources.displayMetrics
            ).toInt().coerceAtLeast(32)

            val bitmap = rasterizeDrawable(drawable, targetPx, lowPower)
            synchronized(this@AppRepository) {
                iconCache.put(app.uniqueKey, bitmap)
            }
            bitmap
        } catch (e: Exception) {
            null
        }
    }

    private fun rasterizeDrawable(drawable: Drawable, sizePx: Int, lowPower: Boolean): Bitmap {
        // Use ARGB_8888 to preserve adaptive icon transparency mask cleanly,
        // while keeping strict pixel dimensions (36dp in Low Power Mode = ~48x48px on Tab A7 Lite)
        val config = Bitmap.Config.ARGB_8888
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, config)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, sizePx, sizePx)
        drawable.draw(canvas)
        return bitmap
    }

    // =========================================================================
    // Multi-Window Intent Launchers for Galaxy Tab A7 Lite (Android 11 - 14+)
    // =========================================================================

    enum class LaunchMode {
        NORMAL,
        SPLIT_SCREEN,
        FREEFORM_POPUP
    }

    fun launchApp(app: AppInfo, mode: LaunchMode) {
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = app.componentName
            }

            when (mode) {
                LaunchMode.NORMAL -> {
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                    context.startActivity(intent)
                }

                LaunchMode.SPLIT_SCREEN -> {
                    // Launches adjacent to the current foreground task in multi-window / split-screen
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or
                            Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                    context.startActivity(intent)
                }

                LaunchMode.FREEFORM_POPUP -> {
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_MULTIPLE_TASK
                    val options = buildFreeformActivityOptions()
                    context.startActivity(intent, options.toBundle())
                }
            }
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "Unable to launch ${app.label}: ${e.localizedMessage}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /**
     * Constructs ActivityOptions for Freeform Pop-up Window centered on the
     * Galaxy Tab A7 Lite 800x1340 / 1340x800 display.
     */
    private fun buildFreeformActivityOptions(): ActivityOptions {
        val options = ActivityOptions.makeBasic()
        val dm: DisplayMetrics = context.resources.displayMetrics
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels

        // Calculate ergonomic pop-up window bounds (65% width, 60% height, centered)
        val popupW = (screenW * 0.65f).toInt()
        val popupH = (screenH * 0.60f).toInt()
        val left = (screenW - popupW) / 2
        val top = (screenH - popupH) / 2
        options.launchBounds = Rect(left, top, left + popupW, top + popupH)

        // Invoke hidden setLaunchWindowingMode(WINDOWING_MODE_FREEFORM = 5)
        try {
            val method = ActivityOptions::class.java.getMethod(
                "setLaunchWindowingMode",
                Int::class.javaPrimitiveType
            )
            method.invoke(options, 5) // 5 = WindowConfiguration.WINDOWING_MODE_FREEFORM
        } catch (_: Throwable) {
            // Fallback: launchBounds alone still triggers freeform on devices with freeform enabled
        }
        return options
    }

    fun openAppDetails(app: AppInfo) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", app.packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
