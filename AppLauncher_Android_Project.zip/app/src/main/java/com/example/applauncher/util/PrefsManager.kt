package com.example.applauncher.util

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_launcher_prefs", Context.MODE_PRIVATE)

    var isLeftEdge: Boolean
        get() = prefs.getBoolean(KEY_LEFT_EDGE, false) // Default right edge for right-thumb reachability
        set(value) = prefs.edit().putBoolean(KEY_LEFT_EDGE, value).apply()

    var handleYOffsetPx: Int
        get() = prefs.getInt(KEY_HANDLE_Y_PX, 320)
        set(value) = prefs.edit().putInt(KEY_HANDLE_Y_PX, value).apply()

    var handleHeightDp: Int
        get() = prefs.getInt(KEY_HANDLE_HEIGHT_DP, 140)
        set(value) = prefs.edit().putInt(KEY_HANDLE_HEIGHT_DP, value.coerceIn(80, 260)).apply()

    var isLowPowerMode: Boolean
        get() = prefs.getBoolean(KEY_LOW_POWER_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_LOW_POWER_MODE, value).apply()

    fun getPinnedApps(): Set<String> {
        return prefs.getStringSet(KEY_PINNED_APPS, emptySet()) ?: emptySet()
    }

    fun togglePinApp(uniqueKey: String): Boolean {
        val current = getPinnedApps().toMutableSet()
        val nowPinned = if (current.contains(uniqueKey)) {
            current.remove(uniqueKey)
            false
        } else {
            current.add(uniqueKey)
            true
        }
        prefs.edit().putStringSet(KEY_PINNED_APPS, current).apply()
        return nowPinned
    }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    companion object {
        const val KEY_LEFT_EDGE = "left_edge"
        const val KEY_HANDLE_Y_PX = "handle_y_px"
        const val KEY_HANDLE_HEIGHT_DP = "handle_height_dp"
        const val KEY_LOW_POWER_MODE = "low_power_mode"
        const val KEY_PINNED_APPS = "pinned_apps"
    }
}
