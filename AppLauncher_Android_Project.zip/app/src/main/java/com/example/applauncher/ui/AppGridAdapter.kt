package com.example.applauncher.ui

import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.applauncher.R
import com.example.applauncher.data.AppRepository
import com.example.applauncher.model.AppInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class AppGridAdapter(
    private val lifecycleScope: CoroutineScope,
    private val repository: AppRepository,
    private val onAppClick: (AppInfo) -> Unit,
    private val onAppAction: (AppInfo, ContextAction) -> Unit
) : ListAdapter<AppInfo, AppGridAdapter.AppViewHolder>(DiffCallback) {

    enum class ContextAction {
        OPEN_NORMAL,
        OPEN_SPLIT_SCREEN,
        OPEN_FREEFORM_POPUP,
        TOGGLE_PIN,
        APP_INFO
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_grid, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onViewRecycled(holder: AppViewHolder) {
        holder.cancelLoad()
        super.onViewRecycled(holder)
    }

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.iv_app_icon)
        private val tvLabel: TextView = itemView.findViewById(R.id.tv_app_label)
        private var iconJob: Job? = null

        fun bind(app: AppInfo) {
            tvLabel.text = app.label
            iconJob?.cancel()

            // Fast synchronous LruCache hit check to eliminate scrolling flicker
            val cached = repository.getCachedIcon(app.uniqueKey)
            if (cached != null) {
                ivIcon.setImageBitmap(cached)
            } else {
                ivIcon.setImageDrawable(null)
                iconJob = lifecycleScope.launch {
                    val bmp = repository.loadIconAsync(app)
                    if (bmp != null) {
                        ivIcon.setImageBitmap(bmp)
                    }
                }
            }

            itemView.setOnClickListener { onAppClick(app) }
            itemView.setOnLongClickListener { view ->
                showMultiWindowPopupMenu(view, app)
                true
            }
        }

        fun cancelLoad() {
            iconJob?.cancel()
            iconJob = null
        }

        private fun showMultiWindowPopupMenu(anchor: View, app: AppInfo) {
            val popup = PopupMenu(anchor.context, anchor)
            popup.menu.apply {
                add(Menu.NONE, 1, 1, "Open Normal")
                add(Menu.NONE, 2, 2, "Open in Split Screen")
                add(Menu.NONE, 3, 3, "Open in Freeform / Pop-up Window")
                add(
                    Menu.NONE,
                    4,
                    4,
                    if (app.isPinned) "Unpin from Favorites" else "Pin to Favorites"
                )
                add(Menu.NONE, 5, 5, "App Info")
            }
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> onAppAction(app, ContextAction.OPEN_NORMAL)
                    2 -> onAppAction(app, ContextAction.OPEN_SPLIT_SCREEN)
                    3 -> onAppAction(app, ContextAction.OPEN_FREEFORM_POPUP)
                    4 -> onAppAction(app, ContextAction.TOGGLE_PIN)
                    5 -> onAppAction(app, ContextAction.APP_INFO)
                }
                true
            }
            popup.show()
        }
    }

    private object DiffCallback : DiffUtil.ItemCallback<AppInfo>() {
        override fun areItemsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean =
            oldItem.uniqueKey == newItem.uniqueKey

        override fun areContentsTheSame(oldItem: AppInfo, newItem: AppInfo): Boolean =
            oldItem == newItem
    }
}
