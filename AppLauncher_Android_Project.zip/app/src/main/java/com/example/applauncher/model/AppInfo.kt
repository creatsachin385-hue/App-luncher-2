package com.example.applauncher.model

import android.content.ComponentName

/**
 * Lightweight, immutable metadata record for a launchable application.
 * Icons are intentionally NOT held here to prevent retaining Bitmaps in list state;
 * icons are fetched on-demand from AppRepository's byte-bounded LruCache.
 */
data class AppInfo(
    val label: String,
    val labelLower: String,
    val packageName: String,
    val activityName: String,
    val t9Signature: String,
    val sectionLetter: String,
    val isPinned: Boolean = false
) {
    val componentName: ComponentName
        get() = ComponentName(packageName, activityName)

    val uniqueKey: String
        get() = "$packageName/$activityName"
}
